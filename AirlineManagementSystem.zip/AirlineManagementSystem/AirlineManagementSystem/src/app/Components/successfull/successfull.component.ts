import { Component } from '@angular/core';

@Component({
  selector: 'app-successfull',
  standalone: false,
  templateUrl: './successfull.component.html',
  styleUrl: './successfull.component.css'
})
export class SuccessfullComponent {

}
