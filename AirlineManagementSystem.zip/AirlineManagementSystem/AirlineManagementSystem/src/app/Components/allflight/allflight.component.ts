import { Component, OnInit } from '@angular/core';
import { FlightService } from '../../Services/flight.service';
import { Flight } from '../../Model/Flight';
import { Router } from '@angular/router';

@Component({
  selector: 'app-allflight',
  standalone: false,
  templateUrl: './allflight.component.html',
  styleUrl: './allflight.component.css'
})
export class AllflightComponent implements OnInit {
    flights: any[] = [];
    flight=new Flight();
  
    constructor(private flightService:FlightService,private router:Router) {}
  
    ngOnInit(): void {
      this.flightService.getAllflights().subscribe(
        (data: any) => {
          this.flights = data;
        },
        (error) => {
          console.error('Error fetching flights', error);
        }
      );
    }
    bookFlight(flightId:any){
      this.router.navigate(['selectflight',flightId])
    }

}
