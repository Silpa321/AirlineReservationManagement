import { Component, OnInit } from '@angular/core';
import { User } from '../../Model/User';
import { UserService } from '../../Services/user.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-createaccount',
  standalone: false,
  templateUrl: './createaccount.component.html',
  styleUrl: './createaccount.component.css'
})
export class CreateaccountComponent implements OnInit {
  constructor(private userService:UserService,private router:Router){}
  user = new User();
  disableSubmit:boolean=true;
  cpass: string = "";
  a:any;
  
  cPassword:any;
 
  isFirstNameValid: boolean = true;
  isLastNameValid: boolean = true;
  emailValid: boolean = true;
  isMobileValid: boolean = true;
  isPasswordValid: boolean = true;
  isPassportValid = true;
  isFavouriteValid: boolean = true;
  findUserByEmail:any;
  findUserByMobile:any;
  isAgeValid: boolean = true;
  saveaccount(password: string, inemail: string, inmobile: string,) {
    console.log(this.saveaccount)
    this.a = this.userService.findUserByEmail(inemail).subscribe(
      Response => {
        this.findUserByEmail = Response
        console.log(Response)
      })

    console.log(this.findUserByEmail)
    console.log(this.findUserByMobile)
    if (this.findUserByEmail != null) {
      alert("THIS EMAILID OR MOBILE NUMBER ALREADY EXISTS")

    } else {
      if (this.cpass == this.user.userPassword) {
        this.userService.saveUser(this.user).subscribe(
          (response:any) => {
          console.log( response);
          alert("ACCOUNT CREATED SUCCESSFULLY")
            this.router.navigate(['login']);
        });
        
      }
      else {
        alert("PASSWORD DOES NOT MATCH CONFIRM PASSWORD")
      }
    }
  }
ngOnInit(): void {
  
}
favouritevalid(event: any) {
  event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim(); //
  console.log(event.target.value)
  this.user.userFavourite = event.target.value
  this.isFavouriteValid = this.user.userFavourite.match(/^[A-Za-z0-9\s]*$/) && this.user.userFavourite.length > 0 ? true : false
  
  this.checkValidation();
}

firstnamevalid(event: any) {
  event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim(); //
  console.log(event.target.value)
  this.user.userFirstName = event.target.value
  this.isFirstNameValid = this.user.userFirstName.match(/^[A-Za-z\s]*$/) && this.user.userFirstName.length > 2 ? true : false
  console.log(this.isFirstNameValid);
  this.checkValidation();
}
lastnamevalid(event: any) {
  event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim();
  this.user.userLastName = event.target.value
  this.isLastNameValid = this.user.userLastName.match("^[A-Za-z\s]*$") && this.user.userLastName.length > 0 ? true : false
  console.log(this.isLastNameValid);
  this.checkValidation();
}
emailvalid(event: any) {
  event.target.value = event.target.value.trim();
  this.user.userEmail = event.target.value
  this.emailValid = this.user.userEmail.match("^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,4}$") ? true : false
  console.log(this.emailValid);
  this.checkValidation();
}


ageValid(event: any) {
  const value = event.target.value;
  this.isAgeValid = value >= 1 && value <= 100;
}

mobileValid(event: any) {
  event.target.value = event.target.value.trim();
  this.user.userMobileNo = event.target.value
  let m = this.user.userMobileNo.split("");
  console.log(m)
  let n = new Set(m);
  console.log(new Set(m));
  console.log(n.size)

  this.isMobileValid = this.user.userMobileNo.match(/^[6-9][0-9]{9}$/) && n.size > 2 ? true : false
  console.log(this.isMobileValid)
  this.checkValidation();
}
passportValid(event: any): void {
  const value = event.target.value;
  this.isPassportValid = /^[A-Z0-9]{6,12}$/.test(value); // basic pattern
}

passwordValid(event: any) {
  event.target.value = event.target.value.trim();
  this.user.userPassword = event.target.value
  this.isPasswordValid = this.user.userPassword.match("^[a-zA-Z0-9._-]+[@|_|&|%|*|$|-][a-zA-Z0-9-]{2,7}$") ? true : false
  console.log(this.passwordValid)
  this.checkValidation();
}
cPasswordValid(event: any) {
  event.target.value = event.target.value.trim();
  this.cPassword = event.target.value
  this.isPasswordValid = this.cPassword.match("^[a-zA-Z0-9._-]+[@|_|&|%|*|$|-][a-zA-Z0-9-]{2,7}$") ? true : false
  console.log(this.passwordValid)
  this.checkValidation();
}

checkValidation(){
  this.disableSubmit=this.isFirstNameValid && this.isLastNameValid && this.isMobileValid && this.emailValid && this.isPassportValid && this.isPasswordValid && this.user.userFirstName!='' && this.user.userLastName!='' && this.user.userEmail!='' && this.user.userMobileNo!=''  && this.user.userFavourite!='' && this.user.userPassword!='' && this.cPassword!='' ?false:true;
  return this.disableSubmit;
}
}





