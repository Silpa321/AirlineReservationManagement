import { Component, OnInit } from '@angular/core';
import { User } from '../../Model/User';
import { UserService } from '../../Services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginvalidationService } from '../../Services/loginvalidation.service';

@Component({
  selector: 'app-profile',
  standalone: false, 
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit{
  user =new User();
  find=this.user;
  userId:any;
  copass :any;
  isMobileValid: Boolean = true;
  isPasswordValid: Boolean = true;
  isPassportNoValid: Boolean= true;
  constructor(private userService:UserService,public loginvalidation:LoginvalidationService,private activateroute:ActivatedRoute,private router:Router){}
  ngOnInit(): void {
    this.userId = sessionStorage.getItem('userId');
    this.userService.getUserbyId(this.userId).subscribe(
      (response:any)=>
      {
        console.log(response);
        this.user=response;
      }

    )
    
  }

  update(userEmail: string, userPassword: string) {
    console.log("hi")
    if (this.copass == userPassword) {
      this.userService.updateUserByEmail(userEmail,this.user).subscribe(

        (Response:any) => { 
          console.log("Updated");
          console.log(Response);
          this.router.navigate(['home', this.userId]) 
        }
      )
    } else {
      alert("PASSWORD DOES NOT MATCH CONFIRM PASSWORD")
    }

  }

  mobileValid(event: any) {
    event.target.value = event.target.value.trim();
    var mobile = event.target.value
    let m = mobile.split("");
    console.log(m)
    let n = new Set(m);
    console.log(new Set(m));
    console.log(n.size)

    this.isMobileValid = mobile.match(/^(0|91)?[6-9][0-9]{9}$/) && n.size > 2 ? true : false
    console.log(this.isMobileValid)
  }

  passportNoValid(event: any) {
    event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim();
    var add = event.target.value
    this.isPassportNoValid = add.match("^[a-zA-Z0-9.,_-]{15,50}$") ? true : false
    console.log(this.passportNoValid)
  }

  passwordValid(event: any) {
    event.target.value = event.target.value.trim();
    var pass = event.target.value
    this.isPasswordValid = pass.match("^[a-zA-Z0-9._-]+[@|_|&|%|*|$|-][a-zA-Z0-9-]{2,5}$") ? true : false
    console.log(this.passwordValid)
  }
  back() {
    console.log(this.userId)
    this.router.navigate(['home',this.userId])
  }
 

}


