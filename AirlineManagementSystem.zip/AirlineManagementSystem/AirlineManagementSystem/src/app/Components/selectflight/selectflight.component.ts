import { Component, OnInit } from '@angular/core';
import { UserService } from '../../Services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FlightService } from '../../Services/flight.service';
import { User } from '../../Model/User';
import { PassengerService } from '../../Services/passenger.service';
import { Passenger } from '../../Model/Passenger';
import { Flight } from '../../Model/Flight';
import { SeatService } from '../../Services/seat.service';
import { Seat } from '../../Model/Seat';
import { BankserverService } from '../../Services/bankserver.service';

@Component({
  selector: 'app-selectflight',
  standalone: false,
  templateUrl: './selectflight.component.html',
  styleUrl: './selectflight.component.css'
})
export class SelectflightComponent implements OnInit {
  user: any = {};
  flight: any;
  userId: any;
  seatSelection: any;
  flightId: any;
  isEditMode: boolean = false;
  userCategory: string = '';
  seatList: Seat[] = [];
  isUserAlsoPassenger: boolean = false;
  selectedPassengerIndex: number = 0;
  passengers: Passenger[] = [];
  userSeatNumber: string = '';
  selectedSeatNumbers: string[] = [];
  currentSelector: 'user' | 'passenger' = 'user';
  selectedSeats: Set<number> = new Set();
  selectedPassenger: Passenger = new Passenger();


  totalAmount: number = 0;
  showPaymentSection: boolean = false;
  isUpiValid: boolean = true;
  b : any;
  a: any;
  upicheck: any;
  c : any;
  paymentMethod: any; // Tracks the selected payment method
  creditCardNumber: any;
  debitCardNumber: any;
  
  upiId: any;
  cardNumber: any;
  cardExpiry: any;
  cvv: any;
  constructor(
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute,
    private flightService: FlightService,
    private passengerService: PassengerService,
    private seatService: SeatService,
    private bankService:BankserverService
  ) {}

  ngOnInit(): void {
    this.flightId = this.route.snapshot.paramMap.get('flightId');
    this.userId = sessionStorage.getItem('userId');

    this.userService.getUserbyId(this.userId).subscribe(
      (response: any) => this.user = response,
      error => console.error("Error fetching user details", error)
    );

    this.flightService.getFlightById(this.flightId).subscribe(
      (response: any) => {
        this.flight = response;
        this.loadSeats(this.flightId);
      },
      error => console.error("Error fetching flight details", error)
    );
  }

  loadSeats(flightId: number) {
    this.seatService.getAllSeatsByFlightId(flightId).subscribe(
      (response: any) => this.seatList = response,
      error => console.error("Error loading seats", error)
    );
  }
  getRows(seatList: Seat[]): Seat[][] {
    const rows: Seat[][] = [];
    let row: Seat[] = [];
  
    seatList.forEach((seat, index) => {
      row.push(seat);
  
      // Assuming that every 6 seats represent a row. Adjust the number based on your seat configuration.
      if ((index + 1) % 6 === 0) {
        rows.push(row);
        row = [];
      }
    });
  
    // Push remaining seats if any
    if (row.length) {
      rows.push(row);
    }
  
    return rows;
  }
  

  isSeatAlreadySelected(seatNumber: string, currentIndex: number): boolean {
    // Check if selected by user
    if (this.isUserAlsoPassenger && this.userSeatNumber === seatNumber) return true;

    // Check if selected by other passengers
    return this.passengers.some((passenger, index) => passenger.pSeatNumber === seatNumber && index !== currentIndex);
  }
  isPassengerFormValid(passenger: Passenger): boolean {
    // Check if all required fields are filled
    return passenger.pFirstName && passenger.pLastName && passenger.pEmail && passenger.pMobileNo && passenger.pPassportNo ? true : false;
  }
  
  
  removePassenger(index: number): void {
    this.passengers.splice(index, 1);
    console.log('Passenger removed at index:', index);
  }

  
  selectSeat(seat: Seat) {
    // If the seat is already booked, show an alert and return
    if (seat.status === 'booked') {
      alert("This seat is already booked. Please select another seat.");
      return;
    }
  
    const seatNumber = seat.seatNumber;
  
    // Check if the seat is already selected by another passenger (including the user)
    const seatTaken = this.passengers.some(p => p.pSeatNumber === seatNumber);
    const isUserSeat = this.userSeatNumber === seatNumber;
  
    if (seatTaken || isUserSeat) {
      alert("Seat already selected by another passenger.");
      return;
    }
  
    // Check if the user is selecting a seat for themselves
    if (this.currentSelector === 'user') {
      this.selectSeatForUser(seatNumber);
    } 
    // Check if it's a passenger (not the user) selecting a seat
    else if (this.currentSelector === 'passenger') {
      // Ensure selectedPassengerIndex is defined and valid
      if (this.selectedPassengerIndex >= 0 && this.selectedPassengerIndex < this.passengers.length) {
        this.selectSeatForPassenger(this.selectedPassengerIndex, seatNumber);
      } else {
        alert("Please select a valid passenger.");
      }
    }
  }
  
  
  
isSeatSelected(seatNumber: string): boolean {
  // Check if the seat is selected by any additional passengers
  const selectedByPassengers = this.passengers.some(p => p.pSeatNumber === seatNumber);

  // Check if the seat is selected by the logged-in user (if applicable)
  const selectedByUser = this.isUserAlsoPassenger && this.userSeatNumber === seatNumber;

  return selectedByPassengers || selectedByUser;
}


  // For user (self as passenger)
  selectSeatForUser(seatNumber: string) {
    this.userSeatNumber = seatNumber;
  
    // Update seat status to 'selected'
    const seatObject = {
      seatNumber: seatNumber,
      status: 'selected'  // Seat is selected but not yet booked
    };
  
    // Update seat status in the backend
    this.seatService.updateSeatStatusbySeatNumberofFlight(seatNumber, this.flightId, seatObject).subscribe({
      next: (response) => {
        console.log('Seat selected for user successfully:', seatNumber);
  
        // Update the seat status locally
        const seatIndex = this.seatList.findIndex(seat => seat.seatNumber === seatNumber);
        if (seatIndex !== -1) {
          this.seatList[seatIndex].status = 'selected';
        }
      },
      error: (err) => {
        console.error('Error updating seat status for user', err);
        alert('An error occurred while selecting the seat. Please try again.');
      }
    });
  }
  

  // For passengers (when the user is not also a passenger)
  selectedSeatsPerPassenger: { [index: number]: string } = {};

  selectSeatForPassenger(index: number, seatNumber: string) {
    // Set the seat number for the selected passenger
    this.passengers[index].pSeatNumber = seatNumber;
  
    // Update seat status to 'selected' for the passenger
    const seatObject = {
      seatNumber: seatNumber,
      status: 'selected'  // Seat is selected but not yet booked
    };
  
    // Update seat status in the backend
    this.seatService.updateSeatStatusbySeatNumberofFlight(seatNumber, this.flightId, seatObject).subscribe({
      next: (response) => {
        console.log('Seat selected for passenger successfully:', seatNumber);
      },
      error: (err) => {
        console.error('Error updating seat status for passenger', err);
        alert('An error occurred while selecting the seat. Please try again.');
      }
    });
  }
  
  

  isSeatSelectedForPassenger(seatNumber: string, passengerIndex: number): boolean {
    return this.selectedSeatsPerPassenger[passengerIndex] === seatNumber;
  }
  

  setSelectedPassenger(index: number) {
    this.selectedPassengerIndex = index;
    this.selectedPassenger = this.passengers[this.selectedPassengerIndex] || { pFirstName: '', pLastName: '', pEmail: '', pMobileNo: '', pPassportNo: '' };
  }

  toggleEdit() {
    this.isEditMode = !this.isEditMode;
  }

  getFlightDuration(departureTime: string, arrivalTime: string): string {
    const dep = new Date(departureTime);
    const arr = new Date(arrivalTime);
    const durationMs = arr.getTime() - dep.getTime();
    const hours = Math.floor(durationMs / (1000 * 60 * 60));
    const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  }

  updateUser() {
    this.userService.updateUserDetails(this.userId, this.user).subscribe(
      (response: any) => {
        alert("Updated successfully");
        this.isEditMode = false;
        this.router.navigate(['selectflight']);
      }
    );
  }

  classifyUserCategory() {
    if (this.user.age != null) {
      if (this.user.age < 12) {
        this.userCategory = 'Child';
      } else if (this.user.age >= 12 && this.user.age < 18) {
        this.userCategory = 'Teenager';
      } else {
        this.userCategory = 'Adult';
      }
    } else {
      this.userCategory = '';
    }
  }

  sanitizeMobile() {
    if (this.user.userMobileNo) {
      this.user.userMobileNo = this.user.userMobileNo.replace(/[^0-9]/g, '').slice(0, 10);
    }
  }

  sanitizePassport() {
    if (this.user.userPassportNo) {
      this.user.userPassportNo = this.user.userPassportNo.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 9);
    }
  }

  addNewPassenger(): void {
  
    // Create new passenger
    const newPassenger = new Passenger();
    newPassenger.pSeatNumber = this.selectedSeatsPerPassenger[this.passengers.length];
    this.passengers.push(newPassenger);
  
    // Clear the selected seat for the next passenger
    delete this.selectedSeatsPerPassenger[this.passengers.length];
  }
  submitPassengers() {
    const finalPassengers = [...this.passengers];
  
    if (this.isUserAlsoPassenger) {
      const userAsPassenger = new Passenger();
      userAsPassenger.pFirstName = this.user.userFirstName;
      userAsPassenger.pLastName = this.user.userLastName;
      userAsPassenger.pEmail = this.user.userEmail;
      userAsPassenger.pMobileNo = this.user.userMobileNo;
      userAsPassenger.pPassportNo = this.user.userPassportNo;
      userAsPassenger.pGender = this.user.userGender;
      userAsPassenger.pAge = this.user.userAge;
      userAsPassenger.pSeatNumber = this.userSeatNumber;
      userAsPassenger.user = this.user;
      userAsPassenger.pflightId = this.flightId; // Set flightId for the user as a passenger
    
      finalPassengers.push(userAsPassenger);
    }
  
    if (finalPassengers.length === 0) {
      alert("Please add at least one passenger or select yourself as a passenger.");
      return;
    }
  
    for (let i = 0; i < finalPassengers.length; i++) {
      const p = finalPassengers[i];
      if (
        !p.pFirstName?.trim() ||
        !p.pLastName?.trim() ||
        !p.pEmail?.trim() ||
        !p.pMobileNo?.trim() ||
        !p.pPassportNo?.trim() ||
        !p.pGender?.trim() ||
        p.pAge <= 0 || 
        !p.pSeatNumber?.trim() || 
        p.pSeatNumber == ""
      ) {
        alert(`Passenger ${i + 1} has missing details or no seat selected.`);
        return;
      }
  
      // Add flightId to each passenger before submitting
      p.pflightId = this.flightId; // Ensure flightId is set for each passenger
    }
  
    console.log("Submitting passengers:", finalPassengers);
  
    this.passengerService.addPassengersToUser(this.userId, this.flightId, finalPassengers).subscribe({
      next: (res) => {
        alert("Passengers added successfully!");
  
        let bookedSeats = 0;
        const totalSeats = finalPassengers.length;
  
        finalPassengers.forEach(p => {
          if (p.pSeatNumber) {
            const seatObject = {
              seatNumber: p.pSeatNumber,
              status: 'booked'
            };
  
            this.seatService.updateSeatStatusbySeatNumberofFlight(p.pSeatNumber, this.flightId, seatObject).subscribe({
              next: () => {
                console.log('Seat booked:', p.pSeatNumber);
                bookedSeats++;
  
                // 🔁 When all seat updates are done, calculate the total amount and display the payment section
                if (bookedSeats === totalSeats) {
                  const totalAmount = finalPassengers.reduce((sum, p) => {
                    const seat = this.seatList.find(s => s.seatNumber === p.pSeatNumber);
                    return sum + Number(seat?.seatPrice || 0);
                  }, 0);
  
                  // Set the totalAmount and toggle the payment section visibility
                  this.totalAmount = totalAmount;
                  this.showPaymentSection = true;
                }
              },
              error: (err) => {
                console.error('Error updating seat status:', err);
              }
            });
          }
        });
      },
      error: (err) => {
        console.error("Error adding passengers", err);
        alert("Something went wrong.");
      }
    });
  }
  
  
  
  
  
  blockExtraDigits(event: KeyboardEvent, maxLength: number): void {
    const input = event.target as HTMLInputElement;
    const isNumber = /^[0-9]$/.test(event.key);
    if (!isNumber || input.value.length >= maxLength) {
      event.preventDefault();
    }
  }

  blockExtraChars(event: KeyboardEvent, maxLength: number): void {
    const input = event.target as HTMLInputElement;
    const isAlphaNum = /^[A-Z0-9]$/.test(event.key.toUpperCase());
    if (!isAlphaNum || input.value.length >= maxLength) {
      event.preventDefault();
    }
  }

  bookTicket() {
    console.log("Booking details: ", this.user, this.flight, this.seatSelection);
    this.router.navigate(['/confirmation']);
  }
 


//payment details 

checkupi(event: any) {
  event.target.value = event.target.value.trim();
  var pass = event.target.value.trim()
  this.isUpiValid = pass.match("^[a-zA-Z0-9._-]+@[a-zA-Z-]{3,8}$") ? true : false
  console.log(this.isUpiValid)
  if (this.isUpiValid == true && pass.length > 0) {
    this.c = false
  }
  else {
    this.c = true
  }
}


  
  //totalAmount: number = 5000; // Example amount

  // Process Payment based on selected method
  processPayment(){

    if (this.paymentMethod == "debitCard") {
      this.bankService.getCardDetailsbyCNumCVVD(this.cardNumber,this.cvv,this.cardExpiry).subscribe(
        Response => {
          console.log(Response)
          console.log(this.cardExpiry)
          if (Response == null) {
            alert("Card details not found")

          }
          else{
            alert("your payment is successfull!!")
            this.router.navigate(['successful'])
          }
    })
      }
      if (this.paymentMethod == "upi") {
      this.bankService.getUpi(this.upiId).subscribe(
        (Response:any) => {
          // this.bank=Response
          console.log(Response)

          if (Response == null) {
            alert("UPI ID DOES NOT EXITS")
          }
          else{
            alert("Payment Successful!");
            this.router.navigate(['successful'], {
          
            });
          }
        });
      }
    }
  
  
  
  onPaymentMethodChange() {
    // Optional: Reset payment detail fields on switch
    this.upiId = '';
    this.cardNumber = '';
    this.cardExpiry = '';
    this.cvv = '';
  }
  // New Method to confirm booking and update seat status in backend
 /* confirmBooking() {
    if (!this.userSeatNumber) {
      alert("Please select a seat.");
      return;
    }

    // Prepare the seat object to update
    const seatObject = {
      seatNumber: this.userSeatNumber,
      status: 'BOOKED', // Mark the seat as booked
      // You can add other properties if necessary
    };

    // Call backend API to confirm the booking and change the seat status
    this.seatService.updateSeatStatusbySeatNumberofFlight(this.userSeatNumber, this.flightId, seatObject).subscribe({
      next: (res) => {
        alert("Booking confirmed!");
        // After confirming, update seat status in the frontend
        this.seatList.forEach(seat => {
          if (seat.seatNumber === this.userSeatNumber) {
            seat.status = 'BOOKED';
          }
        });
      },
      error: (err) => {
        console.error("Error confirming booking", err);
        alert("Something went wrong, please try again.");
      }
    });
  }*/
}