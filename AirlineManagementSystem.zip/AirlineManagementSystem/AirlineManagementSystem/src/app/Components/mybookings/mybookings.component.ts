import { Component, OnInit } from '@angular/core';
import { ReservationService } from '../../Services/reservation.service';

@Component({
  selector: 'app-mybookings',
  standalone: false,
  templateUrl: './mybookings.component.html',
  styleUrl: './mybookings.component.css'
})
export class MybookingsComponent implements OnInit{
  bookings: any;
  userId!: number;

  constructor(private reservationService:ReservationService) {}

  ngOnInit(): void {
    this.userId = Number(sessionStorage.getItem('userId')); // auto fetch logged-in userId
    if (this.userId) {
      this.getBookings();
    }
  }

  getBookings(): void {
    this.reservationService.getTheBookingDetailsByUserId(this.userId).subscribe(
      (data:any) => {
        this.bookings = data;
      },
      (error) => {
        console.error('Error fetching bookings:', error);
      }
    );
  }

}
