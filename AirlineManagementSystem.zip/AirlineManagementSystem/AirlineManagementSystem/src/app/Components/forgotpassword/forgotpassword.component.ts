import { Component, OnInit } from '@angular/core';
import { User } from '../../Model/User';
import { UserService } from '../../Services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgotpassword',
  standalone: false,
  templateUrl: './forgotpassword.component.html',
  styleUrl: './forgotpassword.component.css'
})
export class ForgotpasswordComponent implements OnInit{
  constructor(private userService:UserService,private router:Router){}
  user =new User();
  user1:any;
  userEmail:any;
  userPassword:any;

  cpass:any;
  emailValid: boolean = true;
  isPasswordValid: boolean = true;
  isFavouriteValid: boolean = true;
  ngOnInit(): void {
    
  }
  updatepass() {
    console.log(this.user.userEmail)
    this.userService.forgotpass(this.user.userEmail,this.user.userFavourite).subscribe(
      (Response:any) => {
        this.user1 = Response
        console.log(Response)
        if (Response != null) {
          if (this.cpass == this.user.userPassword) {
            this.userService.updatenewpassbymail(this.user.userEmail,this.user.userPassword,this.user1).subscribe(
              (Response:any)=>
              {
               // if(Response!=null){
                  console.log("changed");
                console.log(Response)
                alert("PASSWORD SUCCESSFULLY CHANGED")
                this.router.navigate(['login']);
                //}
              }
            )
          } else {
            alert("PASSWORD AND CONFIRM PASSWORD DOES NOT MATCH")
          }

        } else {
          alert("EMAIL ID OR FAVOURITE DOES NOT MATCH")

        }
      }
    )


  }
  back()
  {
    this.router.navigate(['login']);
  }
  passwordValid(event: any) {
    event.target.value = event.target.value.trim();
    var pass = event.target.value
    this.isPasswordValid = pass.match("^[a-zA-Z0-9._-]+[@|_|&|%|*|$|-][a-zA-Z0-9-]{2,5}$") ? true : false
    console.log(this.passwordValid)
  }
  emailvalid(event: any) {
    event.target.value = event.target.value.trim();
    var email = event.target.value
    this.emailValid = email.match("^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,4}$") ? true : false
    console.log(this.emailValid)
  }
  favouritevalid(event: any) {
    event.target.value = event.target.value.trim().length > 0 ? event.target.value : event.target.value.trim(); //
    console.log(event.target.value)
    var favourite = event.target.value
    this.isFavouriteValid = favourite.match(/^[A-Za-z0-9\s]*$/) && favourite.length > 0 ? true : false
    
  }
}



