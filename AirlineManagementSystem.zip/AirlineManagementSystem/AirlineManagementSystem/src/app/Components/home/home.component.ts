import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit{
  constructor(private router:Router){}

  userFirstName: string = '';
  userLastName: string = '';
  userId:any;
  ngOnInit(): void {
    this.userFirstName = sessionStorage.getItem('userFirstName') || '';
    this.userLastName = sessionStorage.getItem('userLastName') || '';
  }
  viewAllFlights(){
    this.router.navigate(['allflight']);

  }
  bookTicket(){
    this.router.navigate(['bookyourticket'])
  }
  viewBookings(){
    this.router.navigate(['mybookings'])
  }
  manageProfile() {
    const userId = sessionStorage.getItem('userId'); // or get from auth/user service
    if (userId) {
      this.router.navigate(['profile']);
    } else {
      alert('User not logged in');
    }
  }

}
