import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { WelcomeComponent } from './Components/welcome/welcome.component';
import { HomeComponent } from './Components/home/home.component';
import { ForgotpasswordComponent } from './Components/forgotpassword/forgotpassword.component';
import { CreateaccountComponent } from './Components/createaccount/createaccount.component';
import { AllflightComponent } from './Components/allflight/allflight.component';
import { ProfileComponent } from './Components/profile/profile.component';
import { LogoutComponent } from './Components/logout/logout.component';
import { FooterComponent } from './Components/footer/footer.component';
import { AdminloginComponent } from './AdminOperations/adminlogin/adminlogin.component';
import { AdminwelcomeComponent } from './AdminOperations/adminwelcome/adminwelcome.component';
import { ViewusersComponent } from './AdminOperations/viewusers/viewusers.component';
import { UpdateusersComponent } from './AdminOperations/updateusers/updateusers.component';
import { ManageflightsComponent } from './AdminOperations/manageflights/manageflights.component';
import { AddflightComponent } from './AdminOperations/addflight/addflight.component';
import { UpdateflightComponent } from './AdminOperations/updateflight/updateflight.component';
import { BookticketComponent } from './Components/bookticket/bookticket.component';
import { ManagebookingComponent } from './AdminOperations/managebooking/managebooking.component';
import { AddseatstoFComponent } from './AdminOperations/addseatsto-f/addseatsto-f.component';
import { ViewseatsbyflightIdComponent } from './AdminOperations/viewseatsbyflight-id/viewseatsbyflight-id.component';
import { UpdateseatComponent } from './AdminOperations/updateseat/updateseat.component';
import { SelectflightComponent } from './Components/selectflight/selectflight.component';
import { PaymentComponent } from './Components/payment/payment.component';
import { SuccessfullComponent } from './Components/successfull/successfull.component';
import { MybookingsComponent } from './Components/mybookings/mybookings.component';
import { ViewflightreportsComponent } from './AdminOperations/viewflightreports/viewflightreports.component';




@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    HomeComponent,
    ForgotpasswordComponent,
    CreateaccountComponent,
    AllflightComponent,
    ProfileComponent,
    LogoutComponent,
    FooterComponent,
    AdminloginComponent,
    AdminwelcomeComponent,
    ViewusersComponent,
    UpdateusersComponent,
    ManageflightsComponent,
    AddflightComponent,
    UpdateflightComponent,
    BookticketComponent,
    ManagebookingComponent,
    AddseatstoFComponent,
    ViewseatsbyflightIdComponent,
    UpdateseatComponent,
    SelectflightComponent,
    PaymentComponent,
    SuccessfullComponent,
    MybookingsComponent,
    ViewflightreportsComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
