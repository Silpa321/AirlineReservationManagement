import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './Components/welcome/welcome.component';
import { HomeComponent } from './Components/home/home.component';
import { ForgotpasswordComponent } from './Components/forgotpassword/forgotpassword.component';
import { CreateaccountComponent } from './Components/createaccount/createaccount.component';
import { AllflightComponent } from './Components/allflight/allflight.component';
import { ProfileComponent } from './Components/profile/profile.component';
import { LogoutComponent } from './Components/logout/logout.component';
import { AdminloginComponent } from './AdminOperations/adminlogin/adminlogin.component';
import { AdminwelcomeComponent } from './AdminOperations/adminwelcome/adminwelcome.component';
import { ViewusersComponent } from './AdminOperations/viewusers/viewusers.component';
import { UpdateusersComponent } from './AdminOperations/updateusers/updateusers.component';
import { ManageflightsComponent } from './AdminOperations/manageflights/manageflights.component';
import { AddflightComponent } from './AdminOperations/addflight/addflight.component';
import { UpdateflightComponent } from './AdminOperations/updateflight/updateflight.component';
import { BookticketComponent } from './Components/bookticket/bookticket.component';
import { ManagebookingComponent } from './AdminOperations/managebooking/managebooking.component';
import { AddseatstoFComponent } from './AdminOperations/addseatsto-f/addseatsto-f.component';
import { ViewseatsbyflightIdComponent } from './AdminOperations/viewseatsbyflight-id/viewseatsbyflight-id.component';
import { UpdateseatComponent } from './AdminOperations/updateseat/updateseat.component';
import { SelectflightComponent } from './Components/selectflight/selectflight.component';
import { PaymentComponent } from './Components/payment/payment.component';
import { SuccessfullComponent } from './Components/successfull/successfull.component';
import { MybookingsComponent } from './Components/mybookings/mybookings.component';
import { ViewflightreportsComponent } from './AdminOperations/viewflightreports/viewflightreports.component';




const routes: Routes = [{path:'',component:WelcomeComponent},
  {path:'home',component:HomeComponent},
  {path:'forgotpassword',component:ForgotpasswordComponent},
  {path:'createaccount',component:CreateaccountComponent},
  {path : 'login',component:WelcomeComponent},
  {path :'allflight',component:AllflightComponent},
  {path:'profile',component:ProfileComponent},
  {path:'logout',component:LogoutComponent},
  {path:'home/:userId',component:HomeComponent},
  {path:'adminlogin',component:AdminloginComponent},
  {path:'adminwelcome/:name',component:AdminwelcomeComponent},
  {path:'viewusers',component:ViewusersComponent},
  {path:'updateuser/:userId',component:UpdateusersComponent},
  {path:'manageflight',component:ManageflightsComponent},
  {path:'addflight',component:AddflightComponent},
  {path:'updateflight/:flightId',component:UpdateflightComponent},
  {path:'bookyourticket',component:BookticketComponent},
  {path:'managebooking',component:ManagebookingComponent},
  {path:'addseatstotheflight/:flightId',component:AddseatstoFComponent},
  {path:'viewseats/:flightId',component:ViewseatsbyflightIdComponent},
  {path:'updateseat/:flightId/:seatId',component:UpdateseatComponent},
  {path:'selectflight/:flightId',component:SelectflightComponent},
  {path:'payment',component:PaymentComponent},
  {path:'successful',component:SuccessfullComponent},
  {path:'mybookings',component:MybookingsComponent},
  {path:'viewflightreports',component:ViewflightreportsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
