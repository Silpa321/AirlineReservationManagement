import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../Model/User';

@Injectable({
  providedIn: 'root'
})
export class LoginvalidationService {

  constructor(private httpClient:HttpClient) { }
url="http://localhost:8089/api/user"
  public isUserLoggedin(){ //if user loggedin it will store in session and it will get whenever 
    let user=sessionStorage.getItem('userId')
  return !(user==null) //returns if the user is there means user is not noll
  }
  loginvalidation(user: User): Observable<any> {
    return this.httpClient.post(`${this.url}/login`, user);
  }
  adminLoginValidation(username:any,password:any){
    if((username.trim()==="SilpaRasineni") && (password.trim()==="Shilpa@18")){
      sessionStorage.setItem('authenticateUserAsAdmin',username)
      return true;
    }
    else
    {
      return false;
    }

  }
}
