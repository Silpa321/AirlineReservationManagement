import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Passenger } from '../Model/Passenger';

@Injectable({
  providedIn: 'root'
})
export class PassengerService implements OnInit{

  constructor(private httpClient:HttpClient) { }
   url="http://localhost:8089/api/passenger"
  ngOnInit(): void {
    
  }
  addOnePassengerToUser(passenger:any, userId: any) {
    return this.httpClient.post(`${this.url}/${userId}`, passenger);
  }
  addPassengersToUser(userId: any,flightId:any,passengers:any) {
    return this.httpClient.post(`${this.url}/passengers/${userId}/${flightId}`, passengers);
  }
  getAllPasenger(){
    return this.httpClient.get(`${this.url}`)
  }
  
}
