import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FlightService implements OnInit {
ngOnInit(): void {
  
}
  constructor(private httpClient:HttpClient) { }
  url="http://localhost:8089/api/flight"

  getAllflights(){
    return this.httpClient.get(`${this.url}`)
  }
  addFlight(flight:any){
    return this.httpClient.post(`${this.url}`,flight)
  }
  getFlightById(flightId:any){
    return this.httpClient.get(`${this.url}/${flightId}`)
  }
  deleteFlightById(flightId:any){
    return this.httpClient.delete(`${this.url}/getflightsafterdeleting/${flightId}`)

  }
  updateFlightById(flightId:any,flightObject:any){
    return this.httpClient.put(`${this.url}/${flightId}`,flightObject)
  }
  searchFlightByFromAndTo(from:any,to:any){
    return this.httpClient.get(`${this.url}/search/${from}/${to}`)

  }
}


