import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BankserverService implements OnInit{

  constructor(private httpClient:HttpClient) { }
  url="http://localhost:8089/api/Bankserver"
  ngOnInit(): void {
    
  }
  getCardDetailsbyCNumCVVD(cNum:any,cvv:any,edate:any){
return this.httpClient.get(`${this.url}/findcardnumcvv/${cNum}/${cvv}/${edate}`)

  }
  getUpi(upi:any){
    return this.httpClient.get(`${this.url}/findbyupi/${upi}`)
  }
}
