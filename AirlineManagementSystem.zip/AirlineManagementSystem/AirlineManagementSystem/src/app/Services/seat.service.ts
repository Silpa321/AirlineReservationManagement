import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Seat } from '../Model/Seat';

@Injectable({
  providedIn: 'root'
})
export class SeatService implements OnInit{
  constructor(private httpClient:HttpClient) { }
  url="http://localhost:8089/api/Seat"
  ngOnInit(): void {
    
  }
  addSeatToFlight(seat:any,flightId:any){
    return this.httpClient.post(`${this.url}/flight/${flightId}`,seat)
  }
  addMultipleSeatsToFlight(seats:Seat[], flightId: any, count: number) {
    return this.httpClient.post<Seat[]>(`${this.url}/flight/${flightId}/add-multiple-seats/${count}`, seats);
  }
  getAllSeatsByFlightId(flightId:any){
    return this.httpClient.get(`${this.url}/flight/${flightId}`)
  }  
  updateSeatByFlightId(flightId:any,seatId:any,seatObject:any){
    return this.httpClient.put(`${this.url}/updateseatbyflight/${flightId}/${seatId}`,seatObject);
  }
  deleteSeatByFlightId(flightId:any, seatId:any) {
    return this.httpClient.delete(`${this.url}/deleteseatbyflight/${flightId}/${seatId}`);
  }
  getSeatById(seatId:any){
    return this.httpClient.get(`${this.url}/${seatId}`)
  }
  updateSeatStatusbySeatNumberofFlight(flightId:any,seatNumber:any,seatObject:any){
    return this.httpClient.put(`${this.url}/updateSeatStatus/${seatNumber}/${flightId}`,seatObject)

  }
}
