import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { User } from '../Model/User';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UserService implements OnInit {

  constructor(private httpClient:HttpClient) { }
  url="http://localhost:8089/api/user"
  ngOnInit(): void {
    
    
  }
  public isUserLoggedIn(){
    let user=sessionStorage.getItem('userId')
    return !(user==null)
  }
  logout(){
    sessionStorage.removeItem('userId');
  }
  saveUser(user: User): Observable<User> {
    return this.httpClient.post<User>(`${this.url}`, user);
  }
  
  getallUser(): Observable<User[]> {
    return this.httpClient.get<User[]>(`${this.url}`);
  }
getUserbyId(userId: any): Observable<User> {
  return this.httpClient.get<User>(`${this.url}/${userId}`);
}

deleteuserbyId(userId:any){
  return this.httpClient.delete(`${this.url}/getUserafterremoving/${userId}`);
}
updateUserDetails(userId:any,userObject:any){
  return this.httpClient.put(`${this.url}/${userId}`,userObject);
}
findUserByEmail(userEmail:any){
  console.log(userEmail);
  return this.httpClient.get<User>(`${this.url}/findbyemail/${userEmail}`);
}
findUserByMobile(userMobileNo:any){
  console.log(userMobileNo);
  return this.httpClient.get<User>(`${this.url}/findbyMobileNo/${userMobileNo}`);
}
forgotpass(userEmail:any,userFavourite:any){
  return this.httpClient.get<User>( `${this.url}/findbymailandfav/${userEmail}/${userFavourite}`)
  }
updatenewpassbymail(userEmail:string,npass:string,user:any){
    return this.httpClient.put<User>(`${this.url}/updatenewpass/${userEmail}/${npass}`,user)
  }
  updateUserByEmail(userEmail:string,user:any){
    return this.httpClient.put<User>(`${this.url}/updateUseByEmail/${userEmail}`,user);
  }
}
