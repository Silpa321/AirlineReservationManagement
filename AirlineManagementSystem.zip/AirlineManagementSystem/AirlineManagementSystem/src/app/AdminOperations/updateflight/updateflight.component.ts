import { Component, OnInit } from '@angular/core';
import { Flight } from '../../Model/Flight';
import { FlightService } from '../../Services/flight.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-updateflight',
  standalone: false,
  templateUrl: './updateflight.component.html',
  styleUrl: './updateflight.component.css'
})
export class UpdateflightComponent implements OnInit{
  flight=new Flight();
  flightId:any;
  flightObject:any;
  constructor(private flightService:FlightService,private activateroute:ActivatedRoute,private router:Router){}
ngOnInit(): void {
  this.flightId=this.activateroute.snapshot.params['flightId'];
  this.flightService.getFlightById(this.flightId).subscribe(
    (Response:any)=>{
      this.flightObject=Response;
    }
  )
}
updateFlightDetails(){
  return this.flightService.updateFlightById(this.flightId,this.flightObject).subscribe(
    (response:any)=>{
      alert("✅ Flight is successfully Updated!!");
      this.router.navigate(['manageflight']);
    }
  )

}

}
