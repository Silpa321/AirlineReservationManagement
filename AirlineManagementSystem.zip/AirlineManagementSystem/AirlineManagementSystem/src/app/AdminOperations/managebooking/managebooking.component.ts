import { Component, OnInit } from '@angular/core';
import { PassengerService } from '../../Services/passenger.service';

@Component({
  selector: 'app-managebooking',
  standalone: false,
  templateUrl: './managebooking.component.html',
  styleUrl: './managebooking.component.css'
})
export class ManagebookingComponent implements OnInit{
  passengers:any;

  constructor(private passengerService: PassengerService) { }

  ngOnInit(): void {
    this.loadBookedPassengers();
  }

  loadBookedPassengers(): void {
    this.passengerService.getAllPasenger().subscribe(
      (data:any) => {
        this.passengers = data;
      },
      (error) => {
        console.error('Error loading passengers', error);
      }
    );
  }
}
