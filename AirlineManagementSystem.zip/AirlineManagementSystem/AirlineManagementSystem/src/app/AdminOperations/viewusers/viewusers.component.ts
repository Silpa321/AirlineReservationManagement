import { Component, OnInit } from '@angular/core';
import { User } from '../../Model/User';
import { UserService } from '../../Services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewusers',
  standalone: false,
  templateUrl: './viewusers.component.html',
  styleUrl: './viewusers.component.css'
})
export class ViewusersComponent implements OnInit {
  constructor(private userService:UserService,private router:Router){}

  user=new User();
  sblock:boolean=false;
  userList:any;
  ngOnInit(): void {
    this.userService.getallUser().subscribe(
      (response:any)=>
      {
        this.userList=response;
      }
    )
    
  }
  viewuserDetails(userId:any){
    this.userService.getUserbyId(userId).subscribe(
      (response:any)=>
      {
        if(response!=null)
          this.sblock=true;
          this.user=response;
      }
    )

  }
  deleteuserbyId(userId:any){
    this.userService.deleteuserbyId(userId).subscribe(
      (response:any)=>{
        this.userList=response;
      }
    )

  }
updateUserDetails(userId:any){
  this.router.navigate(['updateuser',userId]);
}

}
