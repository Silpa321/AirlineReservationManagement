import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,  Router } from '@angular/router';
import { SeatService } from '../../Services/seat.service';
import { Seat } from '../../Model/Seat';

@Component({
  selector: 'app-updateseat',
  standalone: false,
  templateUrl: './updateseat.component.html',
  styleUrl: './updateseat.component.css'
})
export class UpdateseatComponent implements OnInit{
  seat: any = {};
  seatId:any;
  flightId:any;
  seatObject=new Seat();


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private seatService: SeatService
  ) {}

  ngOnInit(): void {
   
    this.seatId = this.route.snapshot.params['seatId'];
    this.flightId = this.route.snapshot.params['flightId'];
    this.seatService.getSeatById(this.seatId).subscribe(
      (data:any) => {
      this.seatObject = data;
    });
  }

  updateSeat() {
    this.seatService.updateSeatByFlightId(this.flightId,this.seatId,this.seatObject).subscribe(
      (response:any) => {
      alert('Seat updated successfully!');
      this.router.navigate(['viewseats',this.flightId]); // or wherever you go back to
    });
  }
}
