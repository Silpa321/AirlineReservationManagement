import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../Services/user.service';

@Component({
  selector: 'app-adminwelcome',
  standalone: false,
  templateUrl: './adminwelcome.component.html',
  styleUrl: './adminwelcome.component.css'
})
export class AdminwelcomeComponent implements OnInit {
  constructor(private router:Router,private userService:UserService){}
  ngOnInit(): void {
    
  }
  manageFlights(){
    this.router.navigate(['manageflight'])
  }
manageBookings(){
  this.router.navigate(['managebooking'])
}
manageUsers(){
  this.router.navigate(['viewusers']);

}
viewReports(){
this.router.navigate(['viewflightreports'])
}
}
