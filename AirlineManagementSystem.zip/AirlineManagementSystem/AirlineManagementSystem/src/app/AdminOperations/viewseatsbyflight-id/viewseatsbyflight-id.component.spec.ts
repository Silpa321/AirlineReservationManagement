import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewseatsbyflightIdComponent } from './viewseatsbyflight-id.component';

describe('ViewseatsbyflightIdComponent', () => {
  let component: ViewseatsbyflightIdComponent;
  let fixture: ComponentFixture<ViewseatsbyflightIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewseatsbyflightIdComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewseatsbyflightIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
