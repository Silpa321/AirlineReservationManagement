import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SeatService } from '../../Services/seat.service';

@Component({
  selector: 'app-viewseatsbyflight-id',
  standalone: false,
  templateUrl: './viewseatsbyflight-id.component.html',
  styleUrl: './viewseatsbyflight-id.component.css'
})
export class ViewseatsbyflightIdComponent implements OnInit {
  flightId!: number;
  seatList: any[] = [];
  seats:any;
  constructor(private route: ActivatedRoute, private seatService: SeatService,private router:Router) {}

  ngOnInit(): void {
    this.flightId = Number(this.route.snapshot.paramMap.get('flightId'));
   this.getSeats();
  }

  getSeats(): void {
    this.seatService.getAllSeatsByFlightId(this.flightId).subscribe(
      (response:any) => {
        //console.log(response);
        this.seatList=response;
      }
    )

}
updateSeat(seatId:any){
  this.router.navigate(['updateseat',this.flightId,seatId])
  }
deleteSeat(seatId:any){
  
    this.seatService.deleteSeatByFlightId(this.flightId, seatId).subscribe(
     
      (response:any)=>{
        this.seatList=response;
      },
      (error) => {
        console.error(error);
        alert('❌ Failed to delete seat.');
      }
    );

}
}
