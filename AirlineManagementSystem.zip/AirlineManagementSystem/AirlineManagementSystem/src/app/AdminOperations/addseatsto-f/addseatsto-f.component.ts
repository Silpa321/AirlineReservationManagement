import { Component, OnInit } from '@angular/core';
import { Seat } from '../../Model/Seat';
import { SeatService } from '../../Services/seat.service';
import { Flight } from '../../Model/Flight';
import { ActivatedRoute, Router } from '@angular/router';
import { FlightService } from '../../Services/flight.service';

@Component({
  selector: 'app-addseatsto-f',
  standalone: false,
  templateUrl: './addseatsto-f.component.html',
  styleUrl: './addseatsto-f.component.css'
})
export class AddseatstoFComponent implements OnInit{
  seat = new Seat();
  flight = new Flight();
  flightId: any;
  classType:any;
  seatCount: number = 0;
  totalSeats: number = 0;
  existingSeats: number = 0;

  constructor(
    private seatService: SeatService,
    private flightService: FlightService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.flightId = this.route.snapshot.paramMap.get('flightId');
    console.log("Flight ID:", this.flightId);

    // Fetch total capacity from flight
    this.flightService.getFlightById(this.flightId).subscribe((flight: any) => {
      this.totalSeats = flight.totalSeats;
      console.log('Total Flight Capacity:', this.totalSeats);
    });

    // Fetch existing seats for the flight
    this.seatService.getAllSeatsByFlightId(this.flightId).subscribe(
      (seats: any) => {
      this.existingSeats = seats.length;
      console.log('Seats Already Added:', this.existingSeats);
    });
  }

  onSubmit() {
    const remainingSeats = this.totalSeats - this.existingSeats;

    if (this.seatCount > remainingSeats) {
      alert(`❌ Cannot add ${this.seatCount} seat(s). Only ${remainingSeats} seat(s) remaining!`);
      return;
    }

    const seatsToAdd: Seat[] = [];
    for (let i = 0; i <this.seatCount; i++) {
      const newSeat = { ...this.seat };
      newSeat.seatId = null;
      seatsToAdd.push(newSeat);
    }

    this.seatService.addMultipleSeatsToFlight(seatsToAdd, this.flightId, this.seatCount).subscribe(
      (response: any) => {
        alert(`✅${this.seatCount} Seats successfully added!`);
        this.router.navigate(['manageflight']);
      },
      (error: any) => {
        console.error('Error adding seats:', error);
      }
    );
  }
}

