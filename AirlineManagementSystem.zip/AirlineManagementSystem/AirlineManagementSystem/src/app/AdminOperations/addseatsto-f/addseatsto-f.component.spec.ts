import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddseatstoFComponent } from './addseatsto-f.component';

describe('AddseatstoFComponent', () => {
  let component: AddseatstoFComponent;
  let fixture: ComponentFixture<AddseatstoFComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddseatstoFComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddseatstoFComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
