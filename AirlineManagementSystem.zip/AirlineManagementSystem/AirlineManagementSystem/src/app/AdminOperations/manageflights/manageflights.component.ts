import { Component, OnInit } from '@angular/core';
import { FlightService } from '../../Services/flight.service';
import { Flight } from '../../Model/Flight';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manageflights',
  standalone: false,
  templateUrl: './manageflights.component.html',
  styleUrl: './manageflights.component.css'
})
export class ManageflightsComponent implements OnInit {
  flight=new Flight();
  flightList:any;
  constructor(private flightService:FlightService,private router:Router) { }
 flightId:any;
 fblock:boolean=false;
  ngOnInit(): void {
    this.flightService.getAllflights().subscribe(
      (data:any) => {
      this.flightList = data;
    });
  }
  openFlightForm(){
    this.router.navigate(['addflight'])
  }
  viewFlight(flightId: any) {
    this.flightService.getFlightById(flightId).subscribe((response: any) => {
      if (response != null) {
        this.flight = response;
        this.fblock = true;
        this.flightId = flightId;
      }
    });
  }
  deleteFlight(flightId:any){
    this.flightService.deleteFlightById(flightId).subscribe(
      (response:any)=>{
        this.flightList=response;
      }
    )
  }
  updateFlight(flightId:any){
    this.router.navigate(['updateflight',flightId]);
  }
  addSeatsToFlight(flightId:any){
    this.router.navigate(['addseatstotheflight',flightId])
  }
  viewSeats(flightId:any){
    this.router.navigate(['viewseats',flightId]);
  }
}
