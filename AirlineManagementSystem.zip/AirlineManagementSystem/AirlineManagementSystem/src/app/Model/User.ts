export class User{
    userId:number |null;
    userFirstName:string;
    userLastName:string;
    userEmail:string;
    userMobileNo:string;
    userFavourite:string;
    userPassword:string;
    userPassportNo:string;
    userGender:string;
    userAge:number;
    constructor(){
        this.userId=null;
        this.userFirstName="";
        this.userLastName="";
        this.userEmail="";
        this.userMobileNo="";
        this.userPassword="";
        this.userPassportNo="";
        this.userFavourite="";
        this.userGender="";
        this.userAge=0;
    }

    
}