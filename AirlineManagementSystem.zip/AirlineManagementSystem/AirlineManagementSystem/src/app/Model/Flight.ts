export class Flight{
    flightId:number |null;
    flightCode:string;
    departureAirport:string;
    arrivalAirport:string;
    departureTime:string;
    arrivalTime:string;
    totalSeats:number;
    flightAirline:string;
    flightAirlineCountry:string;
    constructor(){
        this.flightId=null;
        this.flightCode="";
        this.totalSeats=0;
        this.departureAirport="";
        this.arrivalAirport="";
        this.departureTime="";
        this.arrivalTime="";
        this.flightAirline="";
        this.flightAirlineCountry=""
    }
}