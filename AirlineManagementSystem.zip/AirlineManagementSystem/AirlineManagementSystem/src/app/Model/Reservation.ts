export class Reservation{
    rId:number |null;
    bookingDate:string;
    journeyDate:string;
    rStatus:string;
    rsource:string;
    rdestination:string;
    amount:number;
    constructor(){
        this.rId=null;
        this.bookingDate="";
        this.journeyDate="";
        this.rStatus="";
        this.rsource="";
        this.rdestination="";
        this.amount=0;
    }

}