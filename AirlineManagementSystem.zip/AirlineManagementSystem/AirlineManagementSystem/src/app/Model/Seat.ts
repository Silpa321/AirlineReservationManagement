export class Seat{
    seatId:number |null;
    seatNumber:string;
    seatType:string;
    classType:string;
    status:string;
    seatPrice:number;
    constructor(){
        this.seatId=null;
        this.seatNumber="";
        this.seatType="";
        this.classType="";
        this.status="";
        this.seatPrice=0;
    }
}